// JavaScript Document

$(document).ready(function(){
	$('.mobile-view').click(function(){
	$('.desktop-view').toggleClass('expand');
});

$()
});

